
jQuery code:

